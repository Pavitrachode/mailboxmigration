import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileText, CheckCircle2, AlertTriangle, XCircle, Loader2, FilterX } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

// Dummy data for batches
const MOCK_BATCHES = [
  { id: "BATCH-041", date: "Today, 10:30 AM", count: 25, size: "142 GB", status: "Completed" },
  { id: "BATCH-040", date: "Yesterday, 02:15 PM", count: 50, size: "380 GB", status: "Completed" },
  { id: "BATCH-039", date: "Yesterday, 09:00 AM", count: 12, size: "85 GB", status: "Warning" },
  { id: "BATCH-038", date: "Oct 12, 11:45 PM", count: 100, size: "1.2 TB", status: "Completed" },
  { id: "BATCH-037", date: "Oct 12, 08:30 AM", count: 5, size: "12 GB", status: "Failed" },
  { id: "BATCH-036", date: "Oct 11, 02:00 PM", count: 80, size: "950 GB", status: "Completed" },
  { id: "BATCH-035", date: "Oct 10, 11:15 AM", count: 15, size: "210 GB", status: "Warning" },
];

export default function Reports() {
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);

  const filteredBatches = filterStatus 
    ? MOCK_BATCHES.filter(batch => batch.status === filterStatus)
    : MOCK_BATCHES;

  const handleExport = () => {
    setIsExporting(true);
    
    // Simulate generation delay
    setTimeout(() => {
      // 1. Create dummy CSV content
      const csvContent = [
        "Batch ID,Date,Mailbox Count,Data Size,Status,Notes",
        ...filteredBatches.map(b => `${b.id},${b.date},${b.count},${b.size},${b.status},N/A`)
      ].join("\n");

      // 2. Create a Blob from the CSV string
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      
      // 3. Create a temporary download link and trigger it
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `migration_report_${filterStatus ? filterStatus.toLowerCase() : 'all'}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // 4. Reset state and show toast
      setIsExporting(false);
      toast({
        title: "Export Successful",
        description: `Downloaded ${filterStatus ? filterStatus : 'all'} migration records.`,
      });
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Migration Reports</h2>
          <p className="text-muted-foreground text-sm mt-1">Detailed logs and analytics for your Exchange to Azure migrations.</p>
        </div>
        <Button variant="outline" onClick={handleExport} disabled={isExporting}>
          {isExporting ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Download className="w-4 h-4 mr-2" />
          )}
          {isExporting ? "Generating CSV..." : filterStatus ? `Export ${filterStatus} (CSV)` : "Export All Data (CSV)"}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
         <Card 
          className={`shadow-sm border-l-4 border-l-success cursor-pointer transition-all hover:shadow-md ${filterStatus === 'Completed' ? 'ring-2 ring-success/50 bg-success/5' : ''}`}
          onClick={() => setFilterStatus(filterStatus === 'Completed' ? null : 'Completed')}
         >
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Successful Migrations</p>
              <CheckCircle2 className="h-5 w-5 text-success" />
            </div>
            <div className="text-3xl font-bold">894</div>
            <p className="text-xs text-muted-foreground mt-1">Total data transferred: 4.2 TB</p>
          </CardContent>
        </Card>
        <Card 
          className={`shadow-sm border-l-4 border-l-warning cursor-pointer transition-all hover:shadow-md ${filterStatus === 'Warning' ? 'ring-2 ring-warning/50 bg-warning/5' : ''}`}
          onClick={() => setFilterStatus(filterStatus === 'Warning' ? null : 'Warning')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Completed with Warnings</p>
              <AlertTriangle className="h-5 w-5 text-warning" />
            </div>
            <div className="text-3xl font-bold">42</div>
            <p className="text-xs text-muted-foreground mt-1">Skipped corrupt items</p>
          </CardContent>
        </Card>
        <Card 
          className={`shadow-sm border-l-4 border-l-destructive cursor-pointer transition-all hover:shadow-md ${filterStatus === 'Failed' ? 'ring-2 ring-destructive/50 bg-destructive/5' : ''}`}
          onClick={() => setFilterStatus(filterStatus === 'Failed' ? null : 'Failed')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Failed Migrations</p>
              <XCircle className="h-5 w-5 text-destructive" />
            </div>
            <div className="text-3xl font-bold">7</div>
            <p className="text-xs text-muted-foreground mt-1">Requires admin intervention</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Migration Batches {filterStatus && `- ${filterStatus}`}</CardTitle>
            <CardDescription>History of completed and failed migration batches.</CardDescription>
          </div>
          {filterStatus && (
            <Button variant="ghost" size="sm" onClick={() => setFilterStatus(null)}>
              <FilterX className="w-4 h-4 mr-2" />
              Clear Filter
            </Button>
          )}
        </CardHeader>
        <CardContent className="p-0">
           <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>Batch ID</TableHead>
                <TableHead>Date / Time</TableHead>
                <TableHead>Mailboxes</TableHead>
                <TableHead>Data Size</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBatches.length > 0 ? (
                filteredBatches.map((batch) => (
                  <TableRow key={batch.id}>
                    <TableCell className="font-medium font-mono text-sm">{batch.id}</TableCell>
                    <TableCell className="text-muted-foreground">{batch.date}</TableCell>
                    <TableCell>{batch.count}</TableCell>
                    <TableCell>{batch.size}</TableCell>
                    <TableCell>
                      {batch.status === 'Completed' && <Badge variant="secondary" className="bg-success/10 text-success">Completed</Badge>}
                      {batch.status === 'Warning' && <Badge variant="secondary" className="bg-warning/10 text-warning-foreground">Warning</Badge>}
                      {batch.status === 'Failed' && <Badge variant="secondary" className="bg-destructive/10 text-destructive">Failed</Badge>}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 w-8 p-0"
                        onClick={() => {
                          // In a mockup, we can't actually open a new tab with server logs,
                          // but we can simulate the browser behavior by trying to open a dummy route
                          // or just showing the toast and opening a blank tab as a placeholder.
                          window.open(`/logs/${batch.id}`, '_blank');
                          
                          toast({
                            title: `Viewing Log for ${batch.id}`,
                            description: "Detailed migration logs opened in a new tab.",
                          });
                        }}
                      >
                        <FileText className="h-4 w-4" />
                        <span className="sr-only">View Log</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                    No batches found matching this filter.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
