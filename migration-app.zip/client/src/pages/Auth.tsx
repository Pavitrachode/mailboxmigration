import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Server, Cloud, ArrowRight } from "lucide-react";

export default function Auth() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate connection delay
    setTimeout(() => {
      setIsLoading(false);
      setLocation("/dashboard");
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-muted/30 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-8 items-center">
        <div className="space-y-6 hidden md:block">
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-primary mb-2">Exchange to Azure</h1>
            <p className="text-xl text-muted-foreground">Enterprise Mailbox Migration</p>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-4 bg-background p-4 rounded-lg border shadow-sm">
              <div className="bg-primary/10 p-3 rounded-full">
                <Server className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold">On-Premises Discovery</h3>
                <p className="text-sm text-muted-foreground">Scan and categorize existing Exchange mailboxes automatically.</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 bg-background p-4 rounded-lg border shadow-sm">
              <div className="bg-primary/10 p-3 rounded-full">
                <Cloud className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold">Azure Migration</h3>
                <p className="text-sm text-muted-foreground">Seamlessly transfer user, shared, and resource mailboxes to M365.</p>
              </div>
            </div>
          </div>
        </div>

        <Card className="w-full max-w-md mx-auto shadow-lg border-primary/10">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl">Connect Environment</CardTitle>
            <CardDescription>
              Enter your Exchange admin credentials to begin discovery.
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleConnect}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="server">Exchange Server URL</Label>
                <Input id="server" defaultValue="https://exchange.company.local" required data-testid="input-server-url" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="domain">Domain / Username</Label>
                <Input id="domain" defaultValue="CORP\admin" required data-testid="input-username" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" defaultValue="password123" required data-testid="input-password" />
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={isLoading} data-testid="button-connect">
                {isLoading ? (
                  "Connecting..."
                ) : (
                  <>
                    Connect & Discover <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
}
