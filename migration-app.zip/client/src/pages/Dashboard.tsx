import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Server, Users, CloudUpload, AlertTriangle, CheckCircle2, PlayCircle, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Mock data for mailboxes
const MOCK_MAILBOXES = [
  { id: "1", name: "John Doe", email: "jdoe@company.local", type: "User", size: "4.2 GB", items: 12450, status: "Ready", readiness: "High" },
  { id: "2", name: "Jane Smith", email: "jsmith@company.local", type: "User", size: "8.1 GB", items: 28900, status: "Ready", readiness: "High" },
  { id: "3", name: "IT Support", email: "support@company.local", type: "Shared", size: "12.5 GB", items: 45000, status: "Migrating", progress: 45, readiness: "High" },
  { id: "4", name: "Conference Room A", email: "conf-a@company.local", type: "Resource", size: "0.5 GB", items: 1200, status: "Ready", readiness: "High" },
  { id: "5", name: "Bob Wilson", email: "bwilson@company.local", type: "User", size: "52.1 GB", items: 156000, status: "Warning", readiness: "Low", warning: "Large mailbox size (>50GB)" },
  { id: "6", name: "Marketing Team", email: "marketing@company.local", type: "Shared", size: "18.3 GB", items: 67000, status: "Completed", readiness: "High" },
  { id: "7", name: "Alice Brown", email: "abrown@company.local", type: "User", size: "2.1 GB", items: 8400, status: "Ready", readiness: "High" },
];

export default function Dashboard() {
  const { toast } = useToast();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isMigrating, setIsMigrating] = useState(false);

  const toggleSelectAll = () => {
    if (selectedIds.size === MOCK_MAILBOXES.filter(m => m.status === 'Ready' || m.status === 'Warning').length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(MOCK_MAILBOXES.filter(m => m.status === 'Ready' || m.status === 'Warning').map(m => m.id)));
    }
  };

  const toggleSelect = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const handleStartMigration = () => {
    if (selectedIds.size === 0) return;
    setIsMigrating(true);
    toast({
      title: "Migration Started",
      description: `Initiated migration for ${selectedIds.size} selected mailboxes to Azure.`,
    });
    // Reset after a brief moment for demo purposes
    setTimeout(() => {
      setSelectedIds(new Set());
      setIsMigrating(false);
    }, 2000);
  };

  const handleCardClick = (title: string) => {
    toast({
      title: `Viewing Details: ${title}`,
      description: `Filtering view to show ${title.toLowerCase()} metrics.`,
    });
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <Card className="shadow-sm border-l-4 border-l-primary cursor-pointer hover:shadow-md transition-all active:scale-[0.98]" onClick={() => handleCardClick("Total Discovered")}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Total Discovered</p>
              <Users className="h-4 w-4 text-primary" />
            </div>
            <div className="text-2xl font-bold">1,248</div>
            <p className="text-xs text-muted-foreground mt-1">across 3 databases</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-l-4 border-l-success cursor-pointer hover:shadow-md transition-all active:scale-[0.98]" onClick={() => handleCardClick("Ready for Cloud")}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Ready for Cloud</p>
              <CheckCircle2 className="h-4 w-4 text-success" />
            </div>
            <div className="text-2xl font-bold">1,102</div>
            <p className="text-xs text-muted-foreground mt-1">88% readiness score</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-l-4 border-l-chart-4 cursor-pointer hover:shadow-md transition-all active:scale-[0.98]" onClick={() => handleCardClick("Currently Migrating")}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Currently Migrating</p>
              <RefreshCw className="h-4 w-4 text-chart-4 animate-spin-slow" />
            </div>
            <div className="text-2xl font-bold">45</div>
            <p className="text-xs text-muted-foreground mt-1">Batch #42 in progress</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-l-4 border-l-warning cursor-pointer hover:shadow-md transition-all active:scale-[0.98]" onClick={() => handleCardClick("Warnings & Issues")}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Warnings / Issues</p>
              <AlertTriangle className="h-4 w-4 text-warning" />
            </div>
            <div className="text-2xl font-bold">101</div>
            <p className="text-xs text-muted-foreground mt-1">Requires manual review</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-l-4 border-l-chart-1 cursor-pointer hover:shadow-md transition-all active:scale-[0.98]" onClick={() => handleCardClick("Est. Time Remaining")}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Est. Time Remaining</p>
              <PlayCircle className="h-4 w-4 text-chart-1" />
            </div>
            <div className="text-2xl font-bold">14h 30m</div>
            <p className="text-xs text-muted-foreground mt-1">Based on current speed</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-l-4 border-l-chart-2 cursor-pointer hover:shadow-md transition-all active:scale-[0.98]" onClick={() => handleCardClick("Total Data Size")}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Total Data Size</p>
              <Server className="h-4 w-4 text-chart-2" />
            </div>
            <div className="text-2xl font-bold">5.8 TB</div>
            <p className="text-xs text-muted-foreground mt-1">Total across mailboxes</p>
          </CardContent>
        </Card>
      </div>

      {/* Migration Queue */}
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between border-b pb-4">
          <div>
            <CardTitle>Mailbox Inventory & Migration Queue</CardTitle>
            <CardDescription>Select mailboxes to migrate to Microsoft 365.</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh Scan
            </Button>
            <Button 
              size="sm" 
              onClick={handleStartMigration} 
              disabled={selectedIds.size === 0 || isMigrating}
              data-testid="button-start-migration"
            >
              <PlayCircle className="w-4 h-4 mr-2" />
              Migrate Selected ({selectedIds.size})
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="w-12 text-center">
                  <Checkbox 
                    checked={selectedIds.size > 0 && selectedIds.size === MOCK_MAILBOXES.filter(m => m.status === 'Ready' || m.status === 'Warning').length}
                    onCheckedChange={toggleSelectAll}
                    data-testid="checkbox-select-all"
                  />
                </TableHead>
                <TableHead>Mailbox</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Size / Items</TableHead>
                <TableHead>Readiness</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {MOCK_MAILBOXES.map((mb) => (
                <TableRow key={mb.id} className="group">
                  <TableCell className="text-center">
                    <Checkbox 
                      checked={selectedIds.has(mb.id)}
                      onCheckedChange={() => toggleSelect(mb.id)}
                      disabled={mb.status === 'Completed' || mb.status === 'Migrating'}
                      data-testid={`checkbox-select-${mb.id}`}
                    />
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{mb.name}</div>
                    <div className="text-xs text-muted-foreground">{mb.email}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-normal text-xs">
                      {mb.type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{mb.size}</div>
                    <div className="text-xs text-muted-foreground">{mb.items.toLocaleString()} items</div>
                  </TableCell>
                  <TableCell>
                    {mb.readiness === "High" ? (
                      <Badge variant="secondary" className="bg-success/10 text-success hover:bg-success/20">High</Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-warning/10 text-warning-foreground hover:bg-warning/20">Low</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {mb.status === 'Ready' && (
                      <span className="flex items-center text-sm text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 mr-1.5 text-muted-foreground" /> Ready
                      </span>
                    )}
                    {mb.status === 'Migrating' && (
                      <div className="space-y-1.5 w-full max-w-[120px]">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-chart-4 flex items-center font-medium">
                            <RefreshCw className="w-3 h-3 mr-1 animate-spin-slow" /> Migrating
                          </span>
                          <span>{mb.progress}%</span>
                        </div>
                        <Progress value={mb.progress} className="h-1.5" />
                      </div>
                    )}
                    {mb.status === 'Warning' && (
                      <span className="flex items-center text-sm text-warning-foreground" title={mb.warning}>
                        <AlertTriangle className="w-4 h-4 mr-1.5" /> Review Needed
                      </span>
                    )}
                    {mb.status === 'Completed' && (
                      <span className="flex items-center text-sm text-success font-medium">
                        <CloudUpload className="w-4 h-4 mr-1.5" /> In Azure
                      </span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
